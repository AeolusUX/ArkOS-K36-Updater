#!/bin/bash

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to reset emulationstation controls? This would delete the current controls and would ask you to set them again.\n"
printf "\nPress A to continue.  Press B to exit.\n"

while true; do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
	
	sudo rm -f /etc/emulationstation/es_input.cfg
	
        if [ $? -eq 0 ]; then
            printf "\nSuccessfully reset the emulationstation controls for your device.\n"
            sleep 5
        else
            printf "\nFailed to set the default controls on standalone emulators for the R33S\n"
            sleep 5
        fi
        exit 0
    fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
        printf "\nExiting without resetting emulation station controls\n"
        sleep 1
        exit 0
    fi
done
