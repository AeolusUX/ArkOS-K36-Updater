#!/bin/bash

# Check if the specific file exists to determine the source path
if [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ]; then
    SOURCE_DIR="/roms/nds/bgx"
    DEST_DIR="/roms/nds/bg"
else
    SOURCE_DIR="/roms2/nds/bgx"
    DEST_DIR="/roms2/nds/bg"
fi

# Verify the source directory exists before attempting to rename
if [ -d "$SOURCE_DIR" ]; then
    # Check if destination directory exists
    if [ -d "$DEST_DIR" ]; then
        echo "Error: Destination directory $DEST_DIR already exists. Please resolve this conflict before running the script."
        exit 1
    fi

    sudo mv -fv "$SOURCE_DIR" "$DEST_DIR"  # Rename the directory
    echo "NDS Overlays have been Activated. The folder has been renamed to $DEST_DIR"
else
    echo "Source directory $SOURCE_DIR does not exist. Nothing to rename."
fi
